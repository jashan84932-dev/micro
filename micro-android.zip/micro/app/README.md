# Micro – voice control for Android

1. Install Android Studio (PC/Mac). New Project > "Empty Views Activity".
   Name: Micro, package: com.micro.assistant, Min SDK: API 28.
2. Replace AndroidManifest.xml and the MainActivity.kt with these files.
   Add MicroService.kt in the same folder as MainActivity.kt.
   Add res/xml/accessibility_config.xml and merge res/values/strings.xml.
3. Plug in your phone (USB debugging on), press Run.
4. In Micro: allow microphone > turn on Micro in Accessibility > Talk to Micro.

Commands: open <app>, go home, go back, recents, notifications, quick settings,
lock screen, scroll down/up, click <text>, type <text>, call <number>,
search <words>, go to <site>, volume up/down, flashlight on/off, set alarm 7:30.

TV commands (after pairing in the app): "tv volume up/down", "tv mute", "tv power",
"tv home", "tv back", "tv up/down/left/right", "tv ok", "tv play/pause",
"tv open youtube / netflix / prime / hotstar".
