package com.micro.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun toast(t: String) = runOnUiThread { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("micro", 0)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun button(label: String, action: () -> Unit) {
            box.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        box.addView(TextView(this).apply { text = "Micro"; textSize = 32f })
        button("1. Allow microphone") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }
        button("2. Turn on Micro in Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("3. Talk to Micro") {
            val s = MicroService.instance
            if (s == null) toast("Turn on Micro in Accessibility first") else s.listen()
        }

        box.addView(TextView(this).apply { text = "\nSmart TV (Android TV / Google TV)"; textSize = 20f })
        val ip = EditText(this).apply {
            hint = "TV address, e.g. 192.168.43.25"
            setText(prefs.getString("tv_ip", ""))
        }
        val code = EditText(this).apply { hint = "Code shown on the TV" }
        fun saveIp() = prefs.edit().putString("tv_ip", ip.text.toString().trim()).apply()

        button("A. Find my TV (turn on TV + hotspot first)") {
            toast("Searching…")
            Thread {
                val found = try { TvRemote.findTv() } catch (e: Exception) { null }
                runOnUiThread {
                    if (found != null) { ip.setText(found); saveIp(); toast("Found TV at $found") }
                    else toast("TV not found. Type its address by hand.")
                }
            }.start()
        }
        box.addView(ip)
        button("B. Pair TV (a code appears on the TV)") {
            saveIp()
            Thread {
                try { TvRemote.startPairing(ip.text.toString().trim()); toast("Type the code from the TV below") }
                catch (e: Exception) { toast("Pairing failed: ${e.message}") }
            }.start()
        }
        box.addView(code)
        button("C. Confirm code") {
            Thread {
                try { TvRemote.finishPairing(code.text.toString()); toast("TV paired! Say: tv volume up") }
                catch (e: Exception) { toast("Wrong code or failed: ${e.message}") }
            }.start()
        }
        setContentView(ScrollView(this).apply { addView(box) })
    }
}
