package com.micro.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.Date
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager
import javax.security.auth.x500.X500Principal

/** Android TV / Google TV remote (the same network protocol the Google TV phone remote uses). */
object TvRemote {
    private const val ALIAS = "micro_tv"
    private var pairSocket: SSLSocket? = null
    private var socket: SSLSocket? = null
    @Volatile private var alive = false
    private val lock = Any()

    // ---------- tiny protobuf helpers ----------
    private fun varint(v0: Long): ByteArray {
        var v = v0
        val o = ByteArrayOutputStream()
        while (v >= 0x80) { o.write(((v and 0x7F) or 0x80).toInt()); v = v ushr 7 }
        o.write(v.toInt())
        return o.toByteArray()
    }
    private fun num(f: Int, v: Long) = varint((f shl 3).toLong()) + varint(v)
    private fun msg(f: Int, b: ByteArray) = varint(((f shl 3) or 2).toLong()) + varint(b.size.toLong()) + b
    private fun str(f: Int, s: String) = msg(f, s.toByteArray())

    private class F(val n: Int, val v: Long, val b: ByteArray?)

    private fun parse(d: ByteArray): List<F> {
        val r = ArrayList<F>()
        var i = 0
        fun rv(): Long {
            var s = 0; var x = 0L
            while (true) {
                val c = d[i++].toInt() and 0xFF
                x = x or ((c and 0x7F).toLong() shl s)
                if (c < 0x80) break
                s += 7
            }
            return x
        }
        while (i < d.size) {
            val k = rv()
            val n = (k shr 3).toInt()
            when ((k and 7).toInt()) {
                0 -> r.add(F(n, rv(), null))
                2 -> { val l = rv().toInt(); r.add(F(n, 0, d.copyOfRange(i, i + l))); i += l }
                1 -> i += 8
                5 -> i += 4
                else -> return r
            }
        }
        return r
    }

    private fun send(o: OutputStream, m: ByteArray) {
        synchronized(o) { o.write(varint(m.size.toLong()) + m); o.flush() }
    }

    private fun read(i: InputStream): ByteArray {
        var len = 0; var s = 0
        while (true) {
            val c = i.read()
            if (c < 0) throw EOFException()
            len = len or ((c and 0x7F) shl s)
            if (c < 0x80) break
            s += 7
        }
        val b = ByteArray(len)
        var p = 0
        while (p < len) {
            val n = i.read(b, p, len - p)
            if (n < 0) throw EOFException()
            p += n
        }
        return b
    }

    // ---------- TLS with a certificate made once and kept in the Android keystore ----------
    private fun sslContext(): SSLContext {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val g = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
            g.initialize(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                    .setKeySize(2048)
                    .setDigests(KeyProperties.DIGEST_NONE, KeyProperties.DIGEST_SHA1, KeyProperties.DIGEST_SHA256,
                        KeyProperties.DIGEST_SHA384, KeyProperties.DIGEST_SHA512)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1, KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                    .setCertificateSubject(X500Principal("CN=micro"))
                    .setCertificateSerialNumber(BigInteger.ONE)
                    .setCertificateNotBefore(Date(System.currentTimeMillis() - 86400000L))
                    .setCertificateNotAfter(Date(System.currentTimeMillis() + 3650L * 86400000L))
                    .build()
            )
            g.generateKeyPair()
        }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply { init(ks, null) }
        // The TV uses its own self-signed certificate, so it can't be checked against a public authority.
        val trustTv = object : X509TrustManager {
            override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        return SSLContext.getInstance("TLSv1.2").apply { init(kmf.keyManagers, arrayOf(trustTv), null) }
    }

    private fun connect(ip: String, port: Int): SSLSocket {
        val s = sslContext().socketFactory.createSocket() as SSLSocket
        s.connect(InetSocketAddress(ip, port), 4000)
        s.startHandshake()
        return s
    }

    // ---------- Pairing (done once) ----------
    private fun outer(f: Int, body: ByteArray) = num(1, 2) + num(2, 200) + msg(f, body)

    private fun expect(i: InputStream, f: Int) {
        val m = parse(read(i))
        val status = m.firstOrNull { it.n == 2 }?.v ?: 0L
        if (status != 200L || m.none { it.n == f }) throw IOException("TV refused (status $status)")
    }

    fun startPairing(ip: String) {
        pairSocket?.close()
        val s = connect(ip, 6467)
        pairSocket = s
        val o = s.outputStream
        val i = s.inputStream
        send(o, outer(10, str(1, "atvremote") + str(2, "Micro")))
        expect(i, 11)
        val hex6 = num(1, 3) + num(2, 6)
        send(o, outer(20, msg(1, hex6) + msg(2, hex6) + num(3, 1)))
        expect(i, 20)
        send(o, outer(30, msg(1, hex6) + num(2, 1)))
        expect(i, 31)
    }

    fun finishPairing(codeText: String) {
        val s = pairSocket ?: throw IOException("Press Pair TV first")
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val mine = (ks.getCertificate(ALIAS) as X509Certificate).publicKey as RSAPublicKey
        val tv = (s.session.peerCertificates[0] as X509Certificate).publicKey as RSAPublicKey
        val code = codeText.trim().uppercase()
        val md = MessageDigest.getInstance("SHA-256")
        md.update(hexInt(mine.modulus)); md.update(hexInt(mine.publicExponent))
        md.update(hexInt(tv.modulus)); md.update(hexInt(tv.publicExponent))
        md.update(hexBytes(code.substring(2)))
        send(s.outputStream, outer(40, msg(1, md.digest())))
        expect(s.inputStream, 41)
        s.close()
        pairSocket = null
    }

    private fun hexInt(n: BigInteger): ByteArray {
        var h = n.toString(16)
        if (h.length % 2 == 1) h = "0$h"
        return hexBytes(h)
    }
    private fun hexBytes(h: String) = ByteArray(h.length / 2) { h.substring(2 * it, 2 * it + 2).toInt(16).toByte() }

    // ---------- Sending commands ----------
    fun key(ctx: Context, keyCode: Int) {
        ensure(ctx)
        send(socket!!.outputStream, msg(10, num(1, keyCode.toLong()) + num(2, 3)))
    }

    fun launch(ctx: Context, link: String) {
        ensure(ctx)
        send(socket!!.outputStream, msg(90, str(1, link)))
    }

    private fun ensure(ctx: Context) {
        synchronized(lock) {
            if (alive && socket?.isClosed == false) return
            val ip = ctx.getSharedPreferences("micro", 0).getString("tv_ip", null)
                ?: throw IOException("TV address not set")
            val s = connect(ip, 6466)
            socket = s
            alive = true
            Thread { listen(s) }.start()
            Thread.sleep(1500) // let the TV finish its hello
        }
    }

    // Answers the TV's hello and keep-alive pings.
    private fun listen(s: SSLSocket) {
        try {
            val o = s.outputStream
            val i = s.inputStream
            while (true) {
                for (f in parse(read(i))) {
                    val b = f.b ?: continue
                    when (f.n) {
                        1 -> send(o, msg(1, num(1, 622) + msg(2,
                            str(1, "Micro") + str(2, "Micro") + num(3, 1) + str(4, "1") +
                                str(5, "com.micro.assistant") + str(6, "1.0"))))
                        2 -> send(o, msg(2, num(1, 622)))
                        8 -> send(o, msg(9, num(1, parse(b).firstOrNull { it.n == 1 }?.v ?: 0L)))
                    }
                }
            }
        } catch (e: Exception) {
        } finally {
            alive = false
            runCatching { s.close() }
        }
    }

    // ---------- Find the TV on the hotspot / Wi-Fi ----------
    fun findTv(): String? {
        val own = HashSet<String>()
        val prefixes = HashSet<String>()
        for (ni in NetworkInterface.getNetworkInterfaces()) {
            if (!ni.isUp || ni.isLoopback || !ni.name.matches(Regex("(wlan|ap|swlan|softap|eth).*"))) continue
            for (a in ni.inetAddresses) if (a is Inet4Address) {
                val h = a.hostAddress ?: continue
                own.add(h); prefixes.add(h.substringBeforeLast("."))
            }
        }
        val found = ConcurrentLinkedQueue<String>()
        val tasks = ArrayList<Callable<Boolean>>()
        for (p in prefixes) for (n in 1..254) {
            val ip = "$p.$n"
            if (ip in own) continue
            tasks.add(Callable {
                try { Socket().use { it.connect(InetSocketAddress(ip, 6466), 300) }; found.add(ip); true }
                catch (e: Exception) { false }
            })
        }
        val pool = Executors.newFixedThreadPool(64)
        pool.invokeAll(tasks)
        pool.shutdown()
        return found.firstOrNull()
    }
}
