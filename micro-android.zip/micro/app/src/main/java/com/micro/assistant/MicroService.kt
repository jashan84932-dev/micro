package com.micro.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class MicroService : AccessibilityService() {

    companion object { var instance: MicroService? = null }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    override fun onServiceConnected() {
        instance = this
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    fun say(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "micro") }

    // ---------- Voice input ----------
    fun listen() {
        Handler(Looper.getMainLooper()).post {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle?) {
                        val said = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        if (said != null) handle(said.lowercase().trim()) else say("I didn't catch that")
                    }
                    override fun onError(error: Int) { say("Sorry, try again") }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
                startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
            }
        }
    }

    // ---------- Command router ----------
    private fun handle(c: String) {
        when {
            c.startsWith("tv ") -> tv(c.removePrefix("tv "))
            c.startsWith("television ") -> tv(c.removePrefix("television "))
            c.startsWith("open ") -> openApp(c.removePrefix("open ").trim())
            c in listOf("go home", "home") -> { performGlobalAction(GLOBAL_ACTION_HOME); say("Home") }
            c in listOf("go back", "back") -> { performGlobalAction(GLOBAL_ACTION_BACK); say("Back") }
            c.contains("recent") -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            c.contains("notification") -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            c.contains("quick settings") -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            c.contains("lock") && c.contains("screen") ->
                if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                else say("Lock screen needs Android 9 or newer")
            c.startsWith("scroll down") -> scroll(true)
            c.startsWith("scroll up") -> scroll(false)
            c.startsWith("click ") || c.startsWith("tap ") -> clickText(c.substringAfter(" ").trim())
            c.startsWith("type ") -> typeText(c.removePrefix("type ").trim())
            c.startsWith("call ") -> dial(c.removePrefix("call ").filter { it.isDigit() || it == '+' })
            c.startsWith("search ") -> web("https://www.google.com/search?q=" + Uri.encode(c.removePrefix("search ")))
            c.startsWith("go to ") -> web("https://" + c.removePrefix("go to ").replace(" dot ", ".").replace(" ", ""))
            c.contains("volume up") -> volume(AudioManager.ADJUST_RAISE)
            c.contains("volume down") -> volume(AudioManager.ADJUST_LOWER)
            c.contains("flashlight on") || c.contains("torch on") -> torch(true)
            c.contains("flashlight off") || c.contains("torch off") -> torch(false)
            c.startsWith("set alarm") || c.startsWith("alarm") -> alarm(c)
            else -> say("I don't know that command yet")
        }
    }

    // ---------- Smart TV ----------
    private val tvKeys = listOf(
        "volume up" to 24, "volume down" to 25, "mute" to 164,
        "power" to 26, "turn off" to 26, "turn on" to 26,
        "home" to 3, "back" to 4, "settings" to 176, "menu" to 82,
        "channel up" to 166, "channel down" to 167,
        "pause" to 85, "play" to 85, "next" to 87, "previous" to 88,
        "select" to 23, "ok" to 23,
        "up" to 19, "down" to 20, "left" to 21, "right" to 22
    )
    private val tvApps = mapOf(
        "youtube" to "https://www.youtube.com",
        "netflix" to "https://www.netflix.com/title",
        "prime" to "https://app.primevideo.com",
        "hotstar" to "https://www.hotstar.com"
    )

    private fun tv(c: String) {
        Thread {
            try {
                if (c.startsWith("open ")) {
                    val app = tvApps.entries.firstOrNull { c.contains(it.key) }
                    if (app == null) say("On the TV I can open YouTube, Netflix, Prime or Hotstar")
                    else { TvRemote.launch(this, app.value); say("Opening on the TV") }
                } else {
                    val k = tvKeys.firstOrNull { c.contains(it.first) }
                    if (k == null) say("I don't know that TV command") else TvRemote.key(this, k.second)
                }
            } catch (e: Exception) {
                say("I can't reach the TV. Check pairing and the hotspot")
            }
        }.start()
    }

    // ---------- Actions ----------
    private fun launch(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }

    private fun openApp(name: String) {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name)
        }
        val i = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (i != null) { launch(i); say("Opening $name") } else say("I can't find $name")
    }

    private fun dial(number: String) {
        if (number.isEmpty()) say("Say the phone number") else launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    }

    private fun web(url: String) = launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun volume(dir: Int) {
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun torch(on: Boolean) {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        runCatching { cm.setTorchMode(cm.cameraIdList[0], on) }
    }

    private fun alarm(c: String) {
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(c) ?: return say("Which time?")
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (c.contains("pm") && h < 12) h += 12
        launch(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        say("Alarm set")
    }

    // ---------- Screen control ----------
    private fun scroll(forward: Boolean) {
        val node = findScrollable(rootInActiveWindow) ?: return say("Nothing to scroll")
        node.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                           else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    private fun clickText(text: String) {
        val hit = rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull()
            ?: return say("I can't see $text")
        var n: AccessibilityNodeInfo? = hit
        while (n != null && !n.isClickable) n = n.parent
        if (n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) say("Clicked") else say("I can't click that")
    }

    private fun typeText(text: String) {
        val field = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return say("Tap a text box first")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
